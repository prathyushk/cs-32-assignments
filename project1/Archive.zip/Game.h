#ifndef GAME_H_
#define GAME_H_

class Arena;

class Game
{
public:
  // Constructor/destructor
  Game(int rows, int cols, int nRobots);
  ~Game();

  // Mutators
  void play();

private:
  Arena* m_arena;
};

#endif //GAME_H_
